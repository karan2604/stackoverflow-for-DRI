﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;

class Program
{
    static async Task Main(string[] args)
    {
        string path = args[0];

        string incidentId = args[1];

        string filePath = Path.Combine(path, $"Incident-{incidentId} Details - IcM.html");
        Console.WriteLine(filePath);

        var htmlDoc = new HtmlDocument();
        htmlDoc.Load(filePath);

        // Extract the <li> tags
        var liNodes = htmlDoc.DocumentNode.SelectNodes("//ul");

        String inputText = "";
        // Store the extracted data in a list
        List<string> liTexts = new List<string>();
        foreach (var li in liNodes)
        {
            inputText += li.InnerText.Trim();
            liTexts.Add(li.InnerText.Trim());
        }

        // Print the extracted data
        //foreach (var text in liTexts)
        //{
            //Console.WriteLine(text);
        //}

        //Console.WriteLine(inputText);
        // Define the pattern to match the specific lines
        //string pattern = @"Impact:.*|Service Bus namespace experienced.*|The root cause was.*|The error was due to.*|No changes were found.*|The errors had gone.*|An email was sent.*|Sent email to customer.*|Key Discussions:.*|Actions Taken:.*|Follow-up Actions:.*";
        string ansPattern = @".{100,}";
        string noisePattern = @"^.{1,99}$";

        // Use Regex to find matches
        MatchCollection ansMatches = Regex.Matches(inputText, ansPattern, RegexOptions.Multiline);
        MatchCollection noiseMatches = Regex.Matches(inputText, noisePattern, RegexOptions.Multiline);

        // Print the matched lines
        foreach (Match match in ansMatches)
        {
            string resultOutput = Path.Combine(path, $"Information_{incidentId}.txt");
            // Append the string to the file, creating the file if it doesn't exist
            File.AppendAllText(resultOutput, match.Value.Trim().ToString() + "\n" + Environment.NewLine);
        }

        /*
        // Print the matched lines
        foreach (Match match in noiseMatches)
        {
            string noiseOutput = Path.Combine(path, $"NoiseOutput_{ incidentId}.txt");
            // Append the string to the file, creating the file if it doesn't exist
            File.AppendAllText(noiseOutput, match.Value.Trim().ToString() + "\n" + Environment.NewLine);
        }*/

        Console.WriteLine("String appended to file successfully.");

    }
}