import requests
import urllib
question_id = '79272012'
post_answer_url = f''
headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
}
#test = "I then decided to provide the IPublishEndpoint interface with IServiceScopeFactory and it seems at first a success as the service start up and it publishes a message without errors but then I realised that the message was never published. It even did not write to the outbox tables in sql.So, I tried testing this situation in a more straight forward scenario. I added the code I was using to publish an audit message to an action method in a controller. I tested it and still it did not publish the message. If I inject IPublishEndpoint into the controller with Dependency Injection the publish works perfectly."
data = {
    'body': 'I then decided to provide the IPublishEndpoint interface with IServiceScopeFactory and it seems at first a success as the service start up and it publishes a message without errors but then I realised that the message was never published. It even did not write to the outbox tables in sql.So, I tried testing this situation in a more straight forward scenario. I added the code I was using to publish an audit message to an action method in a controller. I tested it and still it did not publish the message. If I inject IPublishEndpoint into the controller with Dependency Injection the publish works perfectly.',
    'site': 'stackoverflow.com',
    'access_token': '',
    'key': ''
}
response = requests.post(post_answer_url, headers=headers, data=data)
print(response.status_code)
if response.status_code >= 300:
    print("Error 400: Bad Request")
    #print(response.json())  # This will give you more details about the error
else:
    print("success")