import requests
access_token = ''

if not access_token:
    print("Failed to obtain access token")
else:
    print("Access token obtained successfully")

    # Step 3: Post an answer to a specific question
    question_id = '10660'  # Replace with the actual question ID
    answer_body = 'This is the body of the answer you want to post.'
    post_answer_url = f''

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    data = {
        'body': 'Your answer content here',
        'question_id': question_id,
        'site': 'https://stackapps.com/'
    }

    post_response = requests.post(post_answer_url, headers=headers, data=data)

    if post_response.status_code == 200:
        print("Answer posted successfully!")
    else:
        print(f"Failed to post answer: {post_response.status_code}")
        print(f"Error details: {post_response.text}")